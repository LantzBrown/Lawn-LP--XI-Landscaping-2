(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_5f89e7b3._.js",
  "static/chunks/node_modules_next_997ee082._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_framer-motion_dist_es_24e93cb0._.js",
  "static/chunks/node_modules_motion-dom_dist_es_d0b1a52b._.js",
  "static/chunks/node_modules_ad6096a9._.js"
],
    source: "dynamic"
});
